using System;
using System.Collections;
using System.IO;
using System.Linq;
using Forge.Interface;
using Forge.Pont;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class EpreuveBourg
{
    static IEnumerator etapes;
    static double limite;
    static int derniere = -1;
    static EpreuveBourg() { EditorApplication.update += Avancer; }
    public static void Jouer()
    {
        EditorSceneManager.OpenScene("Assets/ForgeLocal3D/Carte/Forge_Carte.unity");
        var carte = Object.FindFirstObjectByType<CarteDessinee>();
        carte.port = 18081; carte.GetComponent<HorlogeDeCarte>().port = 18081; carte.GetComponent<FicheDeCellule>().port = 18081;
        typeof(EpreuveCabinet).GetMethod("ReglerVue", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic).Invoke(null, null);
        SessionState.SetBool("EpreuveBourg", true); EditorApplication.isPlaying = true;
    }
    static void Avancer()
    {
        if (!SessionState.GetBool("EpreuveBourg", false) || !Application.isPlaying || derniere == Time.frameCount) return;
        derniere = Time.frameCount;
        if (etapes == null) { etapes = Parcours(); limite = EditorApplication.timeSinceStartup + 120; }
        try
        {
            if (EditorApplication.timeSinceStartup > limite) throw new Exception("Délai dépassé");
            if (etapes.MoveNext()) return;
            SessionState.SetBool("EpreuveBourg", false); EditorApplication.Exit(0);
        }
        catch (Exception e)
        {
            File.WriteAllText("preuves/bourg-erreur.txt", e.ToString()); Debug.LogException(e);
            SessionState.SetBool("EpreuveBourg", false); EditorApplication.Exit(1);
        }
    }
    static void Cliquer(CabinetDeCarte cabinet, string nom)
    {
        var bouton = cabinet.GetComponentsInChildren<Button>().Single(b => b.name == nom);
        if (!bouton.interactable) throw new Exception("Commande inactive : " + nom);
        ExecuteEvents.Execute(bouton.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
    }
    static CelluleDeCarte Cellule(CarteDessinee carte, long id)
    {
        var forme = carte.transform.Find("Cellules de la carte/Cellule " + id);
        var mesh = forme.GetComponent<MeshFilter>().sharedMesh;
        var p = (mesh.vertices[mesh.triangles[0]] + mesh.vertices[mesh.triangles[1]] + mesh.vertices[mesh.triangles[2]]) / 3;
        return carte.CelluleSous(forme.TransformPoint(p));
    }
    static IEnumerator Parcours()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        while (carte.CellulesServies <= 0 || cabinet.Partie.Maison == null) yield return null;
        cabinet.Garder(Cellule(carte, 10430)); yield return null;
        Cliquer(cabinet, "Plan du bourg");
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) yield return null;
        for (int i = 0; i < 10; i++) yield return null;
        var dessin = cabinet.GetComponentInChildren<DessinBourg>(); var mesh = dessin.canvasRenderer.GetMesh();
        if (mesh.vertexCount == 0) throw new Exception("Le plan reçu reste invisible");
        int sommets = mesh.vertexCount;
        ScreenCapture.CaptureScreenshot("preuves/bourg-bar.png"); for (int i = 0; i < 10; i++) yield return null;
        float zoom = carte.Vue.Echelle; var centre = carte.Vue.Centre;
        var souris = InputSystem.AddDevice<Mouse>();
        InputSystem.QueueStateEvent(souris, new MouseState { position = new Vector2(400, 400) }); yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = new Vector2(400, 400), scroll = new Vector2(0, -120) });
        for (int i = 0; i < 10; i++) yield return null;
        if (carte.Vue.Echelle != zoom || carte.Vue.Centre != centre) throw new Exception("La carte bouge derrière le plan");
        Cliquer(cabinet, "Revenir à la carte"); yield return null;
        if (cabinet.GetComponentInChildren<DessinBourg>() != null) throw new Exception("Le plan reste ouvert");
        Cliquer(cabinet, "Plan du bourg"); yield return null;
        if (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) throw new Exception("Sélection perdue au retour");
        cabinet.Garder(Cellule(carte, 10466));
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10466 · tick"))) yield return null;
        if (cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) throw new Exception("Ancien plan conservé");
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/bourg-autre-terre.png"); for (int i = 0; i < 10; i++) yield return null;
        File.WriteAllText("preuves/bourg-parcours.json", "{\"sommets_bar\":" + sommets + ",\"retour_selection\":true,\"molette_sans_zoom\":true,\"autre_territoire\":10466}");
        InputSystem.RemoveDevice(souris);
    }
}
