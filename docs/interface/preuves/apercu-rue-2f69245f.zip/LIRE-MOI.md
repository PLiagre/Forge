# Essayer le cabinet de Forge

Double-cliquer sur **Jouer.cmd** dans ce dossier. Le lanceur démarre le monde local, puis le jeu. Il arrête ce monde quand la fenêtre du jeu se ferme. Si le port 8000 est déjà utilisé, il refuse le lancement et affiche la raison.

1. Cliquer sur une maison pour lire son aperçu, puis sur **Choisir cette maison**.
2. Le monde applique ce choix au prochain tick ; cliquer sur **Reprendre** si le temps est en pause.
3. Glisser pour déplacer la carte, utiliser la molette pour zoomer.
4. Faire un clic droit sur une terre pour conserver son dossier à côté de la maison.
5. Ouvrir **Terres et comptes** pour consulter les lieux et les flux reçus.
6. Préparer un prélèvement ou un secours du grenier, relire le récapitulatif, puis confirmer. Un reçu ne remplace pas la lecture du prochain tick.
7. Alterner entre **Puissances** et **Habitants** ; consulter **Autres maisons** pour le journal de l’IA. Le lanceur actuel démarre sans IA : ce dossier le signale.
8. Ouvrir le **Menu** ou appuyer sur Échap pour lire l’aide et régler le volume. Tab parcourt les commandes. Fermer le jeu avec Alt+F4.
9. Après un clic droit sur un territoire, ouvrir **Plan du bourg**, puis **Revenir à la carte** pour garder la sélection.
10. Sur un bourg de votre maison : **Tracer une rue**, placer au moins deux points, saisir largeur et foyers, puis **Relire le tracé** et **Confirmer la rue**. Les pointillés sont le brouillon. **Annuler / Retour** avant confirmation ne dépose rien ; le chantier n’apparaît qu’après son application par le monde.

Aperçu local du 17 octobre 2026 : territoires, commandes, comptes, menu, calques, voisins et plan du bourg (PR #669–674, #676 et #677), plus le tracé de rue préparé sur `direct/interface-rue` (`2f69245f`). Il utilise la vraie simulation de la branche `direct/interface-ecran` et la scène de carte du dépôt. Les 57 tests d’interface passent ; le lancement de cet exécutable affiche les 596 cellules avec la souris active et arrête le service à la fermeture. Les autres scènes et les assets du projet complet ne sont pas intégrés. Il dépend de cet ordinateur et du worktree ; conserver tout ce dossier ensemble.

La police, les couleurs politiques et les étiquettes de la carte sont encore provisoires. La présentation a été vérifiée à 1920 × 1080. Parcelles, bâtiments, ville 3D, dynastie et décisions avancées restent à intégrer.
