using System;
using System.Collections;
using System.IO;
using System.Linq;
using Forge.Interface;
using Forge.Pont;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.UI;
[InitializeOnLoad] public static class EpreuveDesign
{
    static IEnumerator parcours;
    static double fin;
    static int frame;
    static EpreuveDesign() { EditorApplication.update += Avancer; }
    public static void Jouer()
    {
        Directory.CreateDirectory("preuves");
        EditorSceneManager.OpenScene("Assets/ForgeLocal3D/Carte/Forge_Carte.unity");
        var c = UnityEngine.Object.FindFirstObjectByType<CarteDessinee>();
        c.port = 18082; c.GetComponent<HorlogeDeCarte>().port = 18082; c.GetComponent<FicheDeCellule>().port = 18082;
        typeof(EpreuveCabinet).GetMethod("ReglerVue", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic).Invoke(null, null);
        SessionState.SetBool("Design", true); EditorApplication.isPlaying = true;
    }
    static void Avancer()
    {
        if (!SessionState.GetBool("Design", false) || !Application.isPlaying || frame == Time.frameCount) return;
        frame = Time.frameCount;
        if (parcours == null) { parcours = Parcours(); fin = EditorApplication.timeSinceStartup + 180; }
        try
        {
            if (EditorApplication.timeSinceStartup > fin) throw new Exception("Délai dépassé");
            if (parcours.MoveNext()) return;
            SessionState.SetBool("Design", false); EditorApplication.Exit(0);
        }
        catch(Exception e) { File.WriteAllText("preuves/design-erreur.txt", e.ToString()); SessionState.SetBool("Design", false); EditorApplication.Exit(1); }
    }
    static void Clic(CabinetDeCarte c, string nom)
    {
        var b = c.GetComponentsInChildren<Button>().Single(b => b.name == nom);
        if (!b.interactable) throw new Exception("Inactif : " + nom);
        b.onClick.Invoke();
    }
    static IEnumerator Parcours()
    {
        CabinetDeCarte c;
        while ((c = UnityEngine.Object.FindFirstObjectByType<CabinetDeCarte>())?.Partie?.Monde == null) yield return null;
        var carte = c.GetComponent<CarteDessinee>(); var horloge = c.GetComponent<HorlogeDeCarte>();
        while (carte.CellulesPosees <= 0 || (c.Partie.Departs == null && c.Partie.Maison == null) || horloge.Lue == null) yield return null;
        if (carte.CellulesPosees != carte.CellulesServies) throw new Exception("Carte incomplète");
        c.Afficher(); yield return null; var departs = new ClientDeparts(18082, ClientDeparts.DelaiMinimal).Lire(); var depart = departs.Donnees.Fiches[0];
        while (c.Partie.Monde.Donnees.MaisonDuJoueur != null && c.Partie.Maison == null) yield return null;
        if (c.Partie.Maison == null)
        {
            while (!c.Partie.PeutChoisir) yield return null; c.Afficher(); Clic(c, depart.Maison); yield return null;
            ScreenCapture.CaptureScreenshot("preuves/design-choix.png"); for(int i=0;i<15;i++) yield return null;
            while (!c.Partie.PeutChoisir) yield return null; c.Afficher(); Clic(c, "Choisir cette maison");
            while (c.Partie.Recu == null || c.Partie.Occupee) yield return null;
            if (horloge.Lue.JoursParSeconde == 0) Clic(c, "Pause / Reprendre");
            while (c.Partie.Maison?.Presente != true) yield return null;
        }
        if (horloge.Lue.JoursParSeconde != 0) Clic(c, "Pause / Reprendre");
        var dessin = carte.transform.Find("Cellules de la carte/Cellule " + depart.CellId);
        var mesh = dessin.GetComponent<MeshFilter>().sharedMesh;
        var p = (mesh.vertices[mesh.triangles[0]] + mesh.vertices[mesh.triangles[1]] + mesh.vertices[mesh.triangles[2]])/3;
        c.Garder(carte.CelluleSous(dessin.TransformPoint(p)));
        for(int i=0;i<180;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-partie.png"); for(int i=0;i<20;i++) yield return null;
        Clic(c, "Terres et comptes"); for(int i=0;i<180;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-dossier.png"); for(int i=0;i<20;i++) yield return null;
        Clic(c, "Menu"); for(int i=0;i<20;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-menu.png"); for(int i=0;i<20;i++) yield return null;
        Clic(c, "Menu"); Clic(c, "Fermer"); Clic(c, "Plan du bourg");
        for(int i=0;i<180;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-bourg.png"); for(int i=0;i<20;i++) yield return null;
        Clic(c, "Revenir à la carte"); Clic(c, "Prélèvement"); yield return null;
        c.GetComponentsInChildren<InputField>().Single().text = "5";
        yield return null; Clic(c, "Préparer"); for(int i=0;i<20;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-confirmation.png"); for(int i=0;i<20;i++) yield return null;
        Clic(c, "Annuler / Retour"); Clic(c, "Habitants"); for(int i=0;i<20;i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/design-habitants.png"); for(int i=0;i<20;i++) yield return null;
        File.WriteAllText("preuves/design-parcours.txt", "Cellules : " + carte.CellulesServies + "\nMaison : " + c.Partie.Maison.Donnees.Nom + "\nCarte : " + carte.camera.rect.width);
    }
}








