using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Forge.Interface;
using Forge.Pont;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class EpreuveCabinet
{
    static IEnumerator etapes;
    static double limite;
    static int imagePrecedente = -1;
    static EpreuveCabinet() { EditorApplication.update += Avancer; }
    public static void Jouer()
    {
        EditorSceneManager.OpenScene("Assets/ForgeLocal3D/Carte/Forge_Carte.unity");
        var carte = Object.FindFirstObjectByType<CarteDessinee>();
        carte.port = 18081;
        carte.GetComponent<HorlogeDeCarte>().port = 18081;
        carte.GetComponent<FicheDeCellule>().port = 18081;
        ReglerVue(); SessionState.SetBool("EpreuveCabinet", true);
        EditorApplication.isPlaying = true;
    }
    static void Avancer()
    {
        if (!SessionState.GetBool("EpreuveCabinet", false) || !Application.isPlaying || imagePrecedente == Time.frameCount) return;
        imagePrecedente = Time.frameCount;
        if (etapes == null) { etapes = SessionState.GetBool("EpreuveVoisins", false) ? ParcoursVoisins() : Parcours(); limite = EditorApplication.timeSinceStartup + 180; }
        try
        {
            if (EditorApplication.timeSinceStartup > limite) throw new Exception("Délai du parcours dépassé");
            if (etapes.MoveNext()) return;
            SessionState.SetBool("EpreuveCabinet", false); SessionState.SetBool("EpreuveVoisins", false);
            EditorApplication.Exit(0);
        }
        catch (Exception e)
        {
            File.WriteAllText("preuves/cabinet-erreur.txt", e.ToString());
            Debug.LogException(e);
            SessionState.SetBool("EpreuveCabinet", false); SessionState.SetBool("EpreuveVoisins", false);
            EditorApplication.Exit(1);
        }
    }
    static void Cliquer(CabinetDeCarte cabinet, string nom)
    {
        var bouton = cabinet.GetComponentsInChildren<Button>().Single(b => b.name == nom);
        if (!bouton.interactable) throw new Exception("Bouton inactif : " + nom);
        ExecuteEvents.Execute(bouton.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
    }
    static IEnumerator Parcours()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        var horloge = cabinet.GetComponent<HorlogeDeCarte>();
        while (carte.CellulesServies < 0 || !cabinet.Partie.PeutChoisir || horloge.Lue == null) yield return null;
        if (carte.CellulesPosees != carte.CellulesServies || carte.CellulesServies == 0) throw new Exception("Carte incomplète");
        cabinet.Afficher(); var depart = cabinet.Partie.Departs.Donnees.Fiches[0];
        Cliquer(cabinet, depart.Maison);
        yield return null;
        Capturer(cabinet, "preuves/cabinet-choix-reel.png"); for (int f = 0; f < 10; f++) yield return null;
        Cliquer(cabinet, "Choisir cette maison");
        while (cabinet.Partie.Recu == null || cabinet.Partie.Occupee) yield return null;
        if (!cabinet.Partie.Recu.Acceptee || cabinet.Partie.Maison != null) throw new Exception("Choix refusé ou appliqué prématurément");
        Cliquer(cabinet, "Pause / Reprendre");
        while (cabinet.Partie.Maison == null || !cabinet.Partie.Maison.Presente || horloge.Lue.JoursParSeconde == 0) yield return null;
        Cliquer(cabinet, "Pause / Reprendre");
        while (horloge.Lue.JoursParSeconde != 0 || cabinet.Partie.Occupee) yield return null;
        var dessin = carte.transform.Find("Cellules de la carte/Cellule " + depart.CellId);
        var mesh = dessin.GetComponent<MeshFilter>().sharedMesh;
        var p = (mesh.vertices[mesh.triangles[0]] + mesh.vertices[mesh.triangles[1]] + mesh.vertices[mesh.triangles[2]]) / 3;
        var cellule = carte.CelluleSous(dessin.TransformPoint(p));
        if (cellule == null || cellule.CellId != depart.CellId) throw new Exception("Le territoire n’est pas celui du départ reçu");
                var souris = InputSystem.AddDevice<Mouse>();
        var centre = new Vector2(carte.camera.pixelWidth / 2, carte.camera.pixelHeight / 2);
        float echelleAvant = carte.Vue.Echelle;
        InputSystem.QueueStateEvent(souris, new MouseState { position = centre, scroll = new Vector2(0, 120) });
        for (int f = 0; f < 3; f++) yield return null;
        if (carte.Vue.Echelle >= echelleAvant) throw new Exception("La molette ne zoome pas");
        var centreAvant = carte.Vue.Centre;
        InputSystem.QueueStateEvent(souris, new MouseState { position = centre }.WithButton(MouseButton.Middle));
        yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = centre + new Vector2(100, 0), delta = new Vector2(100, 0) }.WithButton(MouseButton.Middle));
        for (int f = 0; f < 3; f++) yield return null;
        if (carte.Vue.Centre == centreAvant) throw new Exception("Le glissement ne déplace pas la carte");
        InputSystem.QueueStateEvent(souris, new MouseState { position = centre });
        carte.Vue.Zoomer(-1, new Vector2(.5f, .5f));
        yield return null;
        var pointEcran = (Vector2)carte.camera.WorldToScreenPoint(dessin.TransformPoint(p));
        InputSystem.QueueStateEvent(souris, new MouseState { position = pointEcran }.WithButton(MouseButton.Right));
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = pointEcran });
        if (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Cellule " + depart.CellId))) throw new Exception("Le clic droit ne conserve pas le territoire");
        cabinet.Afficher();
        var panneau = cabinet.GetComponentsInChildren<Image>().Single(i => i.name == "Votre maison").rectTransform;
        var clic = new PointerEventData(EventSystem.current) { position = RectTransformUtility.WorldToScreenPoint(null, panneau.TransformPoint(panneau.rect.center)) };
        var touches = new List<RaycastResult>();
        cabinet.GetComponentInChildren<GraphicRaycaster>().Raycast(clic, touches);
                if (touches.Count == 0) throw new Exception("Le dossier ne bloque pas les clics");
        InputSystem.QueueStateEvent(souris, new MouseState { position = clic.position }.WithButton(MouseButton.Right));
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = clic.position });
        if (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Cellule " + depart.CellId))) throw new Exception("Un clic sur le dossier a changé le territoire");
        var dossier = cabinet.GetComponent<DossierTerritoire>();
        while (dossier.Document == null) yield return null;
        if (DocumentDuMonde.Entier(dossier.Document.Champs, "cell_id") != depart.CellId) throw new Exception("Mauvais territoire lu");
        for (int f = 0; f < 10; f++) yield return null;
        Capturer(cabinet, "preuves/territoires-haut.png"); for (int f = 0; f < 10; f++) yield return null;
        var defilement = cabinet.GetComponentInChildren<ScrollRect>();
        var positionDossier = RectTransformUtility.WorldToScreenPoint(null, defilement.viewport.TransformPoint(defilement.viewport.rect.center));
        float echelleCarte = carte.Vue.Echelle;
        InputSystem.QueueStateEvent(souris, new MouseState { position = positionDossier });
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = positionDossier, scroll = new Vector2(0, -120) });
        for (int f = 0; f < 10; f++) yield return null;
        if (defilement.verticalNormalizedPosition >= 1) throw new Exception("Le dossier ne défile pas");
        if (carte.Vue.Echelle != echelleCarte) throw new Exception("La molette du dossier zoome la carte");
        Capturer(cabinet, "preuves/territoires-defilement.png"); for (int f = 0; f < 10; f++) yield return null;
        var commandes = cabinet.GetComponent<CommandesMaison>();
        while (!cabinet.GetComponentsInChildren<Button>().Single(b => b.name == "Prélèvement").interactable) yield return null;
        using (var comptes = new ClientMaison(18081, TimeSpan.FromSeconds(10)))
        {
            string id = cabinet.Partie.Maison.Donnees.Id;
            double? anciennePart = comptes.LireComptes(id).Donnees.Part;
            Cliquer(cabinet, "Prélèvement"); yield return null;
            commandes.GetComponentsInChildren<InputField>();
            cabinet.GetComponentInChildren<InputField>().text = "20";
            Cliquer(cabinet, "Préparer"); yield return null;
            Capturer(cabinet, "preuves/commandes-confirmation.png"); for (int f = 0; f < 10; f++) yield return null;
            Cliquer(cabinet, "Confirmer l’ordre");
            while (commandes.Ordre.Recu == null) yield return null;
            if (!commandes.Ordre.Recu.Acceptee) throw new Exception("Prélèvement refusé");
            if (comptes.LireComptes(id).Donnees.Part != anciennePart) throw new Exception("Effet anticipé pendant la pause");
            Capturer(cabinet, "preuves/commandes-recu.png"); for (int f = 0; f < 10; f++) yield return null;
            Cliquer(cabinet, "Pause / Reprendre");
            while (comptes.LireComptes(id).Donnees.Part != .2) yield return null;
            while (horloge.Lue.JoursParSeconde == 0) yield return null;
            Cliquer(cabinet, "Pause / Reprendre");
            while (horloge.Lue.JoursParSeconde != 0) yield return null;
            Cliquer(cabinet, "Annuler / Retour"); yield return null;
            Cliquer(cabinet, "Secours du grenier"); yield return null;
            cabinet.GetComponentInChildren<InputField>().text = "999999999";
            Cliquer(cabinet, "Préparer"); yield return null;
            Cliquer(cabinet, "Confirmer l’ordre");
            while (commandes.Ordre.Recu == null) yield return null;
            if (commandes.Ordre.Recu.Acceptee || !commandes.Ordre.Recu.Presente) throw new Exception("Refus réel du grenier manquant");
            for (int f = 0; f < 10; f++) yield return null;
            Capturer(cabinet, "preuves/commandes-refus.png"); for (int f = 0; f < 10; f++) yield return null;
            File.WriteAllText("preuves/commandes-parcours.json", "{\"part_avant\":" + anciennePart.Value.ToString(System.Globalization.CultureInfo.InvariantCulture) + ",\"part_apres_tick\":0.2,\"pause_sans_effet\":true,\"grenier_refuse\":true}");
        }
        Cliquer(cabinet, "Terres et comptes");
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.Contains("Circulation sur 30 jours"))) yield return null;
        for (int f = 0; f < 30; f++) yield return null;
        Capturer(cabinet, "preuves/comptes-maison.png"); for (int f = 0; f < 10; f++) yield return null;
        Cliquer(cabinet, "Fermer"); yield return null;
        if (cabinet.GetComponentsInChildren<Image>().Any(i => i.name == "Terres et comptes" && i.GetComponent<Button>() == null)) throw new Exception("Le dossier ne ferme pas");
        var menu = cabinet.GetComponent<MenuCabinet>();
        var clavier = InputSystem.AddDevice<Keyboard>();
        InputSystem.QueueStateEvent(clavier, new KeyboardState(Key.Escape));
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(clavier, new KeyboardState());
        if (!menu.Ouvert) throw new Exception("Échap ne montre pas le menu");
        InputSystem.QueueStateEvent(clavier, new KeyboardState(Key.Tab));
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(clavier, new KeyboardState());
        if (EventSystem.current.currentSelectedGameObject.name != "Volume") throw new Exception("Tabulation ne parcourt pas le menu");
        cabinet.GetComponentInChildren<Slider>().value = 0;
        if (AudioListener.volume != 0) throw new Exception("Le silence ne prend pas effet");
        for (int f = 0; f < 3; f++) yield return null;
        Capturer(cabinet, "preuves/menu-cabinet.png"); for (int f = 0; f < 10; f++) yield return null;
        InputSystem.QueueStateEvent(clavier, new KeyboardState(Key.Escape));
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(clavier, new KeyboardState());
        if (menu.Ouvert || DocumentDuMonde.Entier(dossier.Document.Champs, "cell_id") != depart.CellId) throw new Exception("Retour ou sélection perdue");
        InputSystem.RemoveDevice(clavier);
        var calques = cabinet.GetComponent<CalquesCarte>();
        Cliquer(cabinet, "Habitants");
        for (int f = 0; f < 10; f++) yield return null;
        if (!calques.Habitants) throw new Exception("Le calque habitants ne s’active pas");
        var repr = new RepartitionHabitants(cabinet.Partie.Monde.Donnees.Monde);
        if (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.Contains(repr.Legende))) throw new Exception("La légende diffère du monde");
        var blocLu = new MaterialPropertyBlock();
        var cellulesRendues = carte.transform.Find("Cellules de la carte").GetComponentsInChildren<MeshRenderer>();
        int teintees = 0;
        foreach (var rendu in cellulesRendues)
        {
            rendu.GetPropertyBlock(blocLu);
            if (!blocLu.isEmpty) teintees++;
        }
        if (teintees != carte.CellulesServies) throw new Exception("Calque partiellement appliqué");
        Capturer(cabinet, "preuves/calques-habitants.png"); for (int f = 0; f < 10; f++) yield return null;
        Cliquer(cabinet, "Puissances"); for (int f = 0; f < 3; f++) yield return null;
        int conserves = 0;
        foreach (var rendu in cellulesRendues) { rendu.GetPropertyBlock(blocLu); if (!blocLu.isEmpty) conserves++; }
        if (calques.Habitants || conserves != 1) throw new Exception("Les couleurs des puissances ou la sélection ne sont pas restaurées");
        File.WriteAllText("preuves/calques-parcours.json", "{\"cellules_teintees\":" + teintees + ",\"minimum\":" + repr.Minimum + ",\"maximum\":" + repr.Maximum + ",\"retour_puissances\":true,\"selection_conservee\":true}");
        Cliquer(cabinet, "Autres maisons");
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.Contains("Bourg affamé"))) yield return null;
        for (int f = 0; f < 10; f++) yield return null;
        Capturer(cabinet, "preuves/voisins-journal.png"); for (int f = 0; f < 10; f++) yield return null;
        var journal = cabinet.GetComponentsInChildren<ScrollRect>().Single(s => s.transform.parent.name == "Les autres maisons");
        var positionJournal = RectTransformUtility.WorldToScreenPoint(null, journal.viewport.TransformPoint(journal.viewport.rect.center));
        float zoomAvantJournal = carte.Vue.Echelle;
        InputSystem.QueueStateEvent(souris, new MouseState { position = positionJournal });
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = positionJournal, scroll = new Vector2(0, -120) });
        for (int f = 0; f < 10; f++) yield return null;
        if (journal.verticalNormalizedPosition >= 1 || carte.Vue.Echelle != zoomAvantJournal) throw new Exception("Défilement du journal incorrect");
        Capturer(cabinet, "preuves/voisins-defilement.png"); for (int f = 0; f < 10; f++) yield return null;
        Cliquer(cabinet, "Terres et comptes"); yield return null;
        var papierComptes = cabinet.GetComponentsInChildren<Image>().Single(i => i.name == "Terres et comptes" && i.GetComponent<Button>() == null).transform;
        if (papierComptes.GetSiblingIndex() != papierComptes.parent.childCount - 1) throw new Exception("Le dossier rouvert reste masqué");
        File.WriteAllText("preuves/cabinet-parcours.json", JsonUtility.ToJson(new Rapport {
            cellulesServies = carte.CellulesServies, cellulesPosees = carte.CellulesPosees,
            maison = cabinet.Partie.Maison.Donnees.Nom, identifiant = cabinet.Partie.Maison.Donnees.Id,
            territoire = cellule.CellId, tick = horloge.Lue.Tick, vitesse = horloge.Lue.JoursParSeconde,
            choixRecuAuTick = cabinet.Partie.Recu.AppliqueeAuTick.Value, blocagePanneau = touches.Count > 0, zoomSouris = true, glissementSouris = true, clicDroit = true,
            textes = cabinet.GetComponentsInChildren<Text>().Select(t => t.text).ToArray()
        }, true));
    }
    [Serializable] class Rapport
    {
        public int cellulesServies, cellulesPosees;
        public long territoire, tick, choixRecuAuTick;
        public double vitesse;
        public string maison, identifiant;
        public bool blocagePanneau, zoomSouris, glissementSouris, clicDroit;
        public string[] textes;
    }
    public static void Voisins() { SessionState.SetBool("EpreuveVoisins", true); Jouer(); }
    static IEnumerator ParcoursVoisins()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        while (carte.CellulesServies <= 0 || cabinet.Partie.Maison == null) yield return null;
        Cliquer(cabinet, "Autres maisons");
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.Contains("Bourg affamé"))) yield return null;
        for (int f = 0; f < 10; f++) yield return null;
        Capturer(cabinet, "preuves/voisins-journal.png"); for (int f = 0; f < 10; f++) yield return null;
        var journal = cabinet.GetComponentsInChildren<ScrollRect>().Single(s => s.transform.parent.name == "Les autres maisons");
        var position = RectTransformUtility.WorldToScreenPoint(null, journal.viewport.TransformPoint(journal.viewport.rect.center));
        float zoom = carte.Vue.Echelle;
        var souris = InputSystem.AddDevice<Mouse>();
        InputSystem.QueueStateEvent(souris, new MouseState { position = position });
        for (int f = 0; f < 3; f++) yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = position, scroll = new Vector2(0, -120) });
        for (int f = 0; f < 10; f++) yield return null;
        if (journal.verticalNormalizedPosition >= 1 || carte.Vue.Echelle != zoom) throw new Exception("Défilement incorrect du journal");
        Capturer(cabinet, "preuves/voisins-defilement.png"); for (int f = 0; f < 10; f++) yield return null;
        Cliquer(cabinet, "Terres et comptes"); yield return null;
        var papier = cabinet.GetComponentsInChildren<Image>().Single(i => i.name == "Terres et comptes" && i.GetComponent<Button>() == null).transform;
        if (papier.GetSiblingIndex() != papier.parent.childCount - 1) throw new Exception("Le dossier rouvert reste masqué");
        InputSystem.RemoveDevice(souris);
        File.WriteAllText("preuves/voisins-parcours.json", "{\"journal_non_vide\":true,\"molette_sans_zoom\":true,\"dossier_rouvert_au_premier_plan\":true}");
    }
    static void ReglerVue()
    {
        var assembly = typeof(Editor).Assembly;
        var sizesType = assembly.GetType("UnityEditor.GameViewSizes");
        var singleton = typeof(ScriptableSingleton<>).MakeGenericType(sizesType);
        var sizes = singleton.GetProperty("instance").GetValue(null);
        var groupType = assembly.GetType("UnityEditor.GameViewSizeGroupType");
        var group = sizesType.GetMethod("GetGroup").Invoke(sizes, new[] { Enum.Parse(groupType, "Standalone") });
        var sizeType = assembly.GetType("UnityEditor.GameViewSize");
        var kind = assembly.GetType("UnityEditor.GameViewSizeType");
        var size = Activator.CreateInstance(sizeType, System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic,
            null, new object[] { Enum.Parse(kind, "FixedResolution"), 1920, 1080, "Preuve 1080p" }, null);
        group.GetType().GetMethod("AddCustomSize").Invoke(group, new[] { size });
        var total = (int)group.GetType().GetMethod("GetTotalCount").Invoke(group, null);
        var viewType = assembly.GetType("UnityEditor.GameView");
        var view = EditorWindow.GetWindow(viewType);
        viewType.GetProperty("selectedSizeIndex", System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic).SetValue(view, total - 1);
        view.Show();
    }
    static void Capturer(CabinetDeCarte cabinet, string fichier) => ScreenCapture.CaptureScreenshot(fichier);
}







