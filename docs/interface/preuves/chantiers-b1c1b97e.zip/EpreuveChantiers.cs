using System;
using System.Collections;
using System.IO;
using System.Linq;
using Forge.Interface;
using Forge.Pont;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class EpreuveChantiers
{
    static IEnumerator etapes;
    static double limite;
    static int derniere = -1;
    static EpreuveChantiers() { EditorApplication.update += Avancer; }
    public static void Jouer()
    {
        EditorSceneManager.OpenScene("Assets/ForgeLocal3D/Carte/Forge_Carte.unity");
        var carte = Object.FindFirstObjectByType<CarteDessinee>();
        carte.port = 18081; carte.GetComponent<HorlogeDeCarte>().port = 18081; carte.GetComponent<FicheDeCellule>().port = 18081;
        typeof(EpreuveCabinet).GetMethod("ReglerVue", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic).Invoke(null, null);
        SessionState.SetBool("EpreuveChantiers", true); EditorApplication.isPlaying = true;
    }
    static void Avancer()
    {
        if (!SessionState.GetBool("EpreuveChantiers", false) || !Application.isPlaying || derniere == Time.frameCount) return;
        derniere = Time.frameCount;
        if (etapes == null) { etapes = Parcours(); limite = EditorApplication.timeSinceStartup + 120; }
        try
        {
            if (EditorApplication.timeSinceStartup > limite) throw new Exception("Délai dépassé");
            if (etapes.MoveNext()) return;
            SessionState.SetBool("EpreuveChantiers", false); EditorApplication.Exit(0);
        }
        catch (Exception e)
        {
            File.WriteAllText("preuves/chantiers-erreur.txt", e.ToString()); Debug.LogException(e);
            SessionState.SetBool("EpreuveChantiers", false); EditorApplication.Exit(1);
        }
    }
    static void Cliquer(CabinetDeCarte cabinet, string nom)
    {
        var bouton = cabinet.GetComponentsInChildren<Button>().Single(b => b.name == nom);
        if (!bouton.interactable) throw new Exception("Commande inactive : " + nom);
        ExecuteEvents.Execute(bouton.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
    }
    static CelluleDeCarte Cellule(CarteDessinee carte, long id)
    {
        var forme = carte.transform.Find("Cellules de la carte/Cellule " + id);
        var mesh = forme.GetComponent<MeshFilter>().sharedMesh;
        var p = (mesh.vertices[mesh.triangles[0]] + mesh.vertices[mesh.triangles[1]] + mesh.vertices[mesh.triangles[2]]) / 3;
        return carte.CelluleSous(forme.TransformPoint(p));
    }
    static Text Contenu(CabinetDeCarte cabinet) => cabinet.GetComponentsInChildren<Text>().FirstOrDefault(t => t.text.StartsWith("Territoire ") && t.text.Contains("Coût en pièces"));
    static IEnumerator Parcours()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        while (carte.CellulesServies <= 0 || cabinet.Partie.Maison == null) yield return null;
        cabinet.Garder(Cellule(carte, 10430)); yield return null; Cliquer(cabinet, "Plan du bourg"); yield return null;
        Cliquer(cabinet, "Chantiers");
        while (Contenu(cabinet) == null) yield return null;
        string avant = Contenu(cabinet).text;
        if (!avant.Contains("30 / 181") || !avant.Contains("15 kg de grain payés")) throw new Exception("Travail ou paiement réel absent");
        File.WriteAllText("preuves/chantiers-avant.txt", avant);
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/chantiers-bar.png");
        for (int i = 0; i < 10; i++) yield return null;
        using (var http = new System.Net.Http.HttpClient())
            http.PostAsync("http://127.0.0.1:18081/tick?n=1", new System.Net.Http.StringContent("")).GetAwaiter().GetResult().EnsureSuccessStatusCode();
        while (Contenu(cabinet).text == avant) yield return null;
        if (!Contenu(cabinet).text.Contains("35 / 181")) throw new Exception("Avancement au tick absent");
        File.WriteAllText("preuves/chantiers-apres.txt", Contenu(cabinet).text);
        cabinet.Garder(Cellule(carte, 10466));
        while (Contenu(cabinet) == null || !Contenu(cabinet).text.StartsWith("Territoire 10466 ·")) yield return null;
        if (Contenu(cabinet).text.Contains("35 / 181")) throw new Exception("Ancien chantier conservé");
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/chantiers-autre-terre.png");
        for (int i = 0; i < 10; i++) yield return null;
        Cliquer(cabinet, "Fermer"); yield return null;
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/chantiers-acces.png");
        for (int i = 0; i < 10; i++) yield return null;
        Cliquer(cabinet, "Chantiers"); yield return null;
        if (Contenu(cabinet) == null || !Contenu(cabinet).text.StartsWith("Territoire 10466 ·")) throw new Exception("Contexte perdu");
        File.WriteAllText("preuves/chantiers-parcours.json", "{\"travail_recu\":true,\"paiement_grain_recu\":true,\"actualisation_au_tick\":true,\"changement_territoire\":true,\"retour_selection\":true}");
    }
}

