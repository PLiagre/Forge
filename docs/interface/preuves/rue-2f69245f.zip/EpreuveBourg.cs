using System;
using System.Collections;
using System.IO;
using System.Linq;
using Forge.Interface;
using Forge.Pont;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.LowLevel;
using UnityEngine.UI;
using Object = UnityEngine.Object;

[InitializeOnLoad]
public static class EpreuveBourg
{
    static IEnumerator etapes;
    static double limite;
    static int derniere = -1;
    static EpreuveBourg() { EditorApplication.update += Avancer; }
    public static void Jouer()
    {
        EditorSceneManager.OpenScene("Assets/ForgeLocal3D/Carte/Forge_Carte.unity");
        var carte = Object.FindFirstObjectByType<CarteDessinee>();
        carte.port = 18081; carte.GetComponent<HorlogeDeCarte>().port = 18081; carte.GetComponent<FicheDeCellule>().port = 18081;
        typeof(EpreuveCabinet).GetMethod("ReglerVue", System.Reflection.BindingFlags.Static | System.Reflection.BindingFlags.NonPublic).Invoke(null, null);
        SessionState.SetBool("EpreuveBourg", true); EditorApplication.isPlaying = true;
    }
    static void Avancer()
    {
        if (!SessionState.GetBool("EpreuveBourg", false) || !Application.isPlaying || derniere == Time.frameCount) return;
        derniere = Time.frameCount;
        if (etapes == null) { etapes = SessionState.GetBool("EpreuveRue", false) ? ParcoursRue() : Parcours(); limite = EditorApplication.timeSinceStartup + 120; }
        try
        {
            if (EditorApplication.timeSinceStartup > limite) throw new Exception("Délai dépassé");
            if (etapes.MoveNext()) return;
            SessionState.SetBool("EpreuveBourg", false); SessionState.SetBool("EpreuveRue", false); EditorApplication.Exit(0);
        }
        catch (Exception e)
        {
            File.WriteAllText("preuves/bourg-erreur.txt", e.ToString()); Debug.LogException(e);
            SessionState.SetBool("EpreuveBourg", false); SessionState.SetBool("EpreuveRue", false); EditorApplication.Exit(1);
        }
    }
    static void Cliquer(CabinetDeCarte cabinet, string nom)
    {
        var bouton = cabinet.GetComponentsInChildren<Button>().Single(b => b.name == nom);
        if (!bouton.interactable) throw new Exception("Commande inactive : " + nom);
        ExecuteEvents.Execute(bouton.gameObject, new PointerEventData(EventSystem.current), ExecuteEvents.pointerClickHandler);
    }
    static CelluleDeCarte Cellule(CarteDessinee carte, long id)
    {
        var forme = carte.transform.Find("Cellules de la carte/Cellule " + id);
        var mesh = forme.GetComponent<MeshFilter>().sharedMesh;
        var p = (mesh.vertices[mesh.triangles[0]] + mesh.vertices[mesh.triangles[1]] + mesh.vertices[mesh.triangles[2]]) / 3;
        return carte.CelluleSous(forme.TransformPoint(p));
    }
    static IEnumerator Parcours()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        while (carte.CellulesServies <= 0 || cabinet.Partie.Maison == null) yield return null;
        cabinet.Garder(Cellule(carte, 10430)); yield return null;
        Cliquer(cabinet, "Plan du bourg");
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) yield return null;
        for (int i = 0; i < 10; i++) yield return null;
        var dessin = cabinet.GetComponentInChildren<DessinBourg>(); var mesh = dessin.canvasRenderer.GetMesh();
        if (mesh.vertexCount == 0) throw new Exception("Le plan reçu reste invisible");
        int sommets = mesh.vertexCount;
        ScreenCapture.CaptureScreenshot("preuves/bourg-bar.png"); for (int i = 0; i < 10; i++) yield return null;
        float zoom = carte.Vue.Echelle; var centre = carte.Vue.Centre;
        var souris = InputSystem.AddDevice<Mouse>();
        InputSystem.QueueStateEvent(souris, new MouseState { position = new Vector2(400, 400) }); yield return null;
        InputSystem.QueueStateEvent(souris, new MouseState { position = new Vector2(400, 400), scroll = new Vector2(0, -120) });
        for (int i = 0; i < 10; i++) yield return null;
        if (carte.Vue.Echelle != zoom || carte.Vue.Centre != centre) throw new Exception("La carte bouge derrière le plan");
        Cliquer(cabinet, "Revenir à la carte"); yield return null;
        if (cabinet.GetComponentInChildren<DessinBourg>() != null) throw new Exception("Le plan reste ouvert");
        Cliquer(cabinet, "Plan du bourg"); yield return null;
        if (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) throw new Exception("Sélection perdue au retour");
        cabinet.Garder(Cellule(carte, 10466));
        while (!cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10466 · tick"))) yield return null;
        if (cabinet.GetComponentsInChildren<Text>().Any(t => t.text.StartsWith("Territoire 10430 · tick"))) throw new Exception("Ancien plan conservé");
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/bourg-autre-terre.png"); for (int i = 0; i < 10; i++) yield return null;
        File.WriteAllText("preuves/bourg-parcours.json", "{\"sommets_bar\":" + sommets + ",\"retour_selection\":true,\"molette_sans_zoom\":true,\"autre_territoire\":10466}");
        InputSystem.RemoveDevice(souris);
    }
    public static void Rue() { SessionState.SetBool("EpreuveRue", true); Jouer(); }
    static DocumentDuMonde LirePlan()
    {
        using (var http = new System.Net.Http.HttpClient())
            return new DocumentDuMonde(http.GetStringAsync("http://127.0.0.1:18081/plan?cell=10430").GetAwaiter().GetResult());
    }
    static void Tick()
    {
        using (var http = new System.Net.Http.HttpClient())
            http.PostAsync("http://127.0.0.1:18081/tick?n=1", new System.Net.Http.StringContent("")).GetAwaiter().GetResult().EnsureSuccessStatusCode();
    }
    static void Pointer(DessinBourg dessin, PlanBourg plan, Vector2 point)
    {
        Vector2 local = (point - (plan.Minimum + plan.Maximum) / 2) * dessin.PixelsParMetre + dessin.rectTransform.rect.center;
        var position = RectTransformUtility.WorldToScreenPoint(null, dessin.rectTransform.TransformPoint(local));
        ExecuteEvents.Execute(dessin.gameObject, new PointerEventData(EventSystem.current) { position = position, button = PointerEventData.InputButton.Left }, ExecuteEvents.pointerClickHandler);
    }
    static IEnumerator ParcoursRue()
    {
        CabinetDeCarte cabinet;
        while ((cabinet = Object.FindFirstObjectByType<CabinetDeCarte>()) == null) yield return null;
        var carte = cabinet.GetComponent<CarteDessinee>();
        while (carte.CellulesServies <= 0 || cabinet.Partie.Maison == null) yield return null;
        cabinet.Garder(Cellule(carte, 10430)); yield return null; Cliquer(cabinet, "Plan du bourg");
        var dossier = cabinet.GetComponent<DossierBourg>();
        while (dossier.Document == null || !cabinet.GetComponentsInChildren<Button>().Single(b => b.name == "Tracer une rue").interactable) yield return null;
        var dessin = cabinet.GetComponentInChildren<DessinBourg>();
        var outil = cabinet.GetComponentInChildren<OutilRue>();
        int avant = DocumentDuMonde.Tableau(LirePlan().Champs, "rues").Count;
        Cliquer(cabinet, "Tracer une rue"); yield return null;
        var plan = new PlanBourg(dossier.Document, 10430);
        Pointer(dessin, plan, new Vector2(-30, 20)); Pointer(dessin, plan, new Vector2(30, 20)); yield return null;
        Cliquer(cabinet, "Relire le tracé"); yield return null;
        Cliquer(cabinet, "Annuler / Retour"); Tick();
        if (outil.Ordre.Brouillon != null || outil.Ordre.Recu != null || DocumentDuMonde.Tableau(LirePlan().Champs, "rues").Count != avant)
            throw new Exception("L’annulation a déposé une rue");
        Cliquer(cabinet, "Tracer une rue"); yield return null;
        plan = new PlanBourg(dossier.Document, 10430);
        Pointer(dessin, plan, new Vector2(-30, 20)); Pointer(dessin, plan, new Vector2(30, 20)); yield return null;
        Cliquer(cabinet, "Relire le tracé"); for (int i = 0; i < 10; i++) yield return null;
        File.WriteAllText("preuves/rue-intention.json", outil.Ordre.Brouillon);
        ScreenCapture.CaptureScreenshot("preuves/rue-confirmation.png"); for (int i = 0; i < 10; i++) yield return null;
        Cliquer(cabinet, "Confirmer la rue"); Cliquer(cabinet, "Confirmer la rue");
        while (outil.Ordre.EnCours || outil.Ordre.Recu == null) yield return null;
        if (!outil.Ordre.Recu.Acceptee) throw new Exception("Rue refusée : " + outil.Ordre.Recu.Erreur + outil.Ordre.Recu.Absence);
        if (DocumentDuMonde.Tableau(LirePlan().Champs, "rues").Count != avant) throw new Exception("Effet avant le tick");
        for (int i = 0; i < 10; i++) yield return null;
        ScreenCapture.CaptureScreenshot("preuves/rue-recu.png"); for (int i = 0; i < 10; i++) yield return null;
        Tick(); var apres = LirePlan(); int rues = DocumentDuMonde.Tableau(apres.Champs, "rues").Count;
        if (rues != avant + 1) throw new Exception("Double dépôt ou rue non appliquée");
        Cliquer(cabinet, "Annuler / Retour");
        cabinet.Garder(Cellule(carte, 10466));
        while (dossier.Document == null || dossier.Cellule != 10466) yield return null;
        for (int i = 0; i < 10; i++) yield return null;
        if (cabinet.GetComponentsInChildren<Button>().Single(b => b.name == "Tracer une rue").interactable) throw new Exception("Outil actif sur une autre maison");
        ScreenCapture.CaptureScreenshot("preuves/rue-terre-etrangere.png"); for (int i = 0; i < 10; i++) yield return null;
        File.WriteAllText("preuves/rue-parcours.json", "{\"annulation_sans_depot\":true,\"pause_sans_effet\":true,\"rues_avant\":" + avant + ",\"rues_apres\":" + rues + ",\"double_confirmation_unique\":true,\"autre_maison_interdite\":true}");
    }
}


